1. Install Solidity

``>npm install -g solc``

1.1 Compile smart contract

``>solcjs --abi greeter.sol``

``>solcjs --bin greeter.sol``

1.2 Generate smart contract wrapper

``\web3j\web3j-3.1.1\bin>.\web3j solidity generate --javaTypes ..\..\..\src\main\resources\contracts\greeter_sol_greeter.bin ..\..\..\src\main\res
ources\contracts\greeter_sol_greeter.abi -o ..\..\..\src\main\java -p at.cpb.ethereum.client.contracts``