package at.cpb.ethereum.client;

import at.cpb.ethereum.client.contracts.ProofOfDelivery_sol_ProofOfDelivery;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.admin.Admin;
import org.web3j.protocol.admin.methods.response.PersonalUnlockAccount;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.Response;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.ClientTransactionManager;
import org.web3j.tx.Contract;
import org.web3j.tx.ManagedTransaction;
import org.web3j.tx.TransactionManager;

import java.io.IOException;
import java.math.BigInteger;
import java.util.function.Function;

/**
 * This class serves as a client to interact with the "Proof of Delivery" Smart Contract.
 */
public class ProofOfDeliverySmartContractClient {

    /**
     * RPC URL of the Ethereum Node.
     */
    private final String nodeRpcUrl;

    /**
     * Hex address of the account.
     */
    private final String account;

    /**
     * Password of the account.
     */
    private final String accountPassword;

    /**
     * Creates a new client instance for interacting with "Proof of Delivery" Smart Contracts.
     *
     * @param nodeRpcUrl RPC URL of the Ethereum Node.
     * @param account Hex address of the account.
     * @param accountPassword Password of the account.
     */
    public ProofOfDeliverySmartContractClient(String nodeRpcUrl, String account, String accountPassword) {
        this.nodeRpcUrl = nodeRpcUrl;
        this.account = account;
        this.accountPassword = accountPassword;
    }

    /**
     * Deploys a new instance of the Smart Contract.
     * Normally this method should be called before sending the actual delivery.
     *
     * @param sendingServicePartnerId Service partner ID of the sending delivery partner.
     * @param sendingServiceDeliveryId Service delivery ID of the sending delivery partner.
     * @param deliveryServiceAccount Hex address of the receiving delivery service account.
     * @param initialWeiValue Ether value in WEI that should be transferred.
     * @return Contract address of the deployed contract.
     */
    public String deployContract(String sendingServicePartnerId, String sendingServiceDeliveryId, String deliveryServiceAccount, BigInteger initialWeiValue) {

        Web3j web3j = Web3j.build(new HttpService(nodeRpcUrl));
        TransactionManager transactionManager = new ClientTransactionManager(web3j, account);

        RemoteCall<ProofOfDelivery_sol_ProofOfDelivery> proofOfDelivery = ProofOfDelivery_sol_ProofOfDelivery.deploy(web3j, transactionManager, ManagedTransaction.GAS_PRICE, Contract.GAS_LIMIT, initialWeiValue, sendingServicePartnerId, sendingServiceDeliveryId, deliveryServiceAccount);

        try {
            unlockAccount();

            return proofOfDelivery.send().getContractAddress();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Confirms the delivery disposition by setting the state to {@code DEPOSITED}.
     *
     * @param contractAddress Contract address of the delivery.
     * @param deliveryServicePartnerId Service partner ID of the receiving delivery partner.
     * @param deliveryServiceDeliveryId Service partner ID of the receiving delivery partner.
     */
    public void confirmDeposition(String contractAddress, String deliveryServicePartnerId, String deliveryServiceDeliveryId) {

        ProofOfDelivery_sol_ProofOfDelivery proofOfDelivery = loadContract(contractAddress);

        try {
            unlockAccount();

            proofOfDelivery.confirmDeposition(deliveryServicePartnerId, deliveryServiceDeliveryId).send();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Confirms the reading of the delivery by setting the state to {@code READ} and
     * by attaching the proof of delivery XML for traceability.
     *
     * @param contractAddress Contract address of the delivery.
     * @param proofOfDeliveryXml Proof of delivery.
     */
    public void confirmReading(String contractAddress, String proofOfDeliveryXml) {

        ProofOfDelivery_sol_ProofOfDelivery proofOfDelivery = loadContract(contractAddress);

        try {
            unlockAccount();

            proofOfDelivery.confirmReading(proofOfDeliveryXml).send();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Confirms the expiration of the delivery by setting the state to {@code EXPIRED} and
     * by attaching the proof of delivery XML for traceability.
     *
     * @param contractAddress Contract address of the delivery.
     * @param proofOfDeliveryXml Proof of delivery.
     */
    public void confirmExpiration(String contractAddress, String proofOfDeliveryXml) {

        ProofOfDelivery_sol_ProofOfDelivery proofOfDelivery = loadContract(contractAddress);

        try {
            unlockAccount();

            proofOfDelivery.confirmExpiration(proofOfDeliveryXml).send();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Methods for reading the state of the contract

    /**
     * Returns the state for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return State.
     */
    public BigInteger getState(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::state);
    }

    /**
     * Returns the proof of delivery for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return Proof of delivery.
     */
    public String getProofOfDelivery(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::proofOfDelivery);
    }

    /**
     * Returns the HEX account address of the sending delivery service for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return HEX account address.
     */
    public String getSendingService(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::sendingService);
    }

    /**
     * Returns the sending service partner ID for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return Sending service partner ID.
     */
    public String getSendingServicePartnerId(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::sendingServicePartnerId);
    }

    /**
     * Returns the sending service delivery ID for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return Sending service delivery ID.
     */
    public String getSendingServiceDeliveryId(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::sendingServiceDeliveryId);
    }

    /**
     * Returns the HEX account address of the receiving delivery service for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return HEX account address.
     */
    public String getDeliveryService(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::deliveryService);
    }

    /**
     * Returns the delivery service partner ID for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return Delivery service partner ID
     */
    public String getDeliveryServicePartnerId(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::deliveryServicePartnerId);
    }

    /**
     * Returns the delivery service delivery ID for the given Smart Contract.
     *
     * @param contractAddress Contract address of the delivery.
     * @return Delivery service delivery ID.
     */
    public String getDeliveryServiceDeliveryId(String contractAddress) {
        return getValueFromContract(contractAddress, ProofOfDelivery_sol_ProofOfDelivery::deliveryServiceDeliveryId);
    }

    private <R> R getValueFromContract(String contractAddress, Function<ProofOfDelivery_sol_ProofOfDelivery, RemoteCall<R>> function) {
        try {
            ProofOfDelivery_sol_ProofOfDelivery proofOfDelivery = loadContract(contractAddress);

            return function.apply(proofOfDelivery).send();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private ProofOfDelivery_sol_ProofOfDelivery loadContract(String contractAddress) {
        Web3j web3j = Web3j.build(new HttpService(nodeRpcUrl));
        TransactionManager transactionManager = new ClientTransactionManager(web3j, account);

        return ProofOfDelivery_sol_ProofOfDelivery.load(contractAddress, web3j, transactionManager, ManagedTransaction.GAS_PRICE, Contract.GAS_LIMIT);
    }

    private void unlockAccount() {
        try {
            Admin admin = Admin.build(new HttpService(nodeRpcUrl));
            PersonalUnlockAccount personalUnlockAccount = admin.personalUnlockAccount(account, accountPassword).send();

            if (personalUnlockAccount.hasError()) {
                Response.Error error = personalUnlockAccount.getError();
                throw new RuntimeException(error.getCode() + ": " + error.getMessage());

            } else if (!personalUnlockAccount.accountUnlocked()) {
                throw new RuntimeException("Account could not be unlocked");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
