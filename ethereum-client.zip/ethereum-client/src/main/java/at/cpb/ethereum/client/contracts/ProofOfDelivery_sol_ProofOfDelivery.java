package at.cpb.ethereum.client.contracts;

import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.abi.datatypes.generated.Uint8;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 3.1.1.
 */
public final class ProofOfDelivery_sol_ProofOfDelivery extends Contract {
    private static final String BINARY = "6060604052604051610f7b380380610f7b8339810160405280805182019190602001805182019190602001805190602001909190505033600160006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550346000819055506000600760006101000a81548160ff0219169083600381111561009c57fe5b021790555082600290805190602001906100b7929190610118565b5081600390805190602001906100ce929190610118565b5080600460006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055505050506101bd565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f1061015957805160ff1916838001178555610187565b82800160010185558215610187579182015b8281111561018657825182559160200191906001019061016b565b5b5090506101949190610198565b5090565b6101ba91905b808211156101b657600081600090555060010161019e565b5090565b90565b610daf806101cc6000396000f3006060604052600436106100ba576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff168063082223cc146100bf5780633320cf321461014d57806334f4cbcc146101db5780633fa4f245146102695780635ee89d931461029257806376b8b15b14610320578063a2c25c6a1461037d578063c19d93fb1461040b578063cf9cb69f14610442578063d3aac07d146104e2578063daa6684b14610537578063fe0853e61461058c575b600080fd5b34156100ca57600080fd5b6100d26105e9565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156101125780820151818401526020810190506100f7565b50505050905090810190601f16801561013f5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b341561015857600080fd5b610160610687565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156101a0578082015181840152602081019050610185565b50505050905090810190601f1680156101cd5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34156101e657600080fd5b6101ee610725565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561022e578082015181840152602081019050610213565b50505050905090810190601f16801561025b5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b341561027457600080fd5b61027c6107c3565b6040518082815260200191505060405180910390f35b341561029d57600080fd5b6102a56107c9565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156102e55780820151818401526020810190506102ca565b50505050905090810190601f1680156103125780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b341561032b57600080fd5b61037b600480803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091905050610867565b005b341561038857600080fd5b6103906109b0565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156103d05780820151818401526020810190506103b5565b50505050905090810190601f1680156103fd5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b341561041657600080fd5b61041e610a4e565b6040518082600381111561042e57fe5b60ff16815260200191505060405180910390f35b341561044d57600080fd5b6104e0600480803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509190803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091905050610a61565b005b34156104ed57600080fd5b6104f5610b49565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b341561054257600080fd5b61054a610b6f565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b341561059757600080fd5b6105e7600480803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091905050610b95565b005b60058054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561067f5780601f106106545761010080835404028352916020019161067f565b820191906000526020600020905b81548152906001019060200180831161066257829003601f168201915b505050505081565b60028054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561071d5780601f106106f25761010080835404028352916020019161071d565b820191906000526020600020905b81548152906001019060200180831161070057829003601f168201915b505050505081565b60068054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156107bb5780601f10610790576101008083540402835291602001916107bb565b820191906000526020600020905b81548152906001019060200180831161079e57829003601f168201915b505050505081565b60005481565b60088054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561085f5780601f106108345761010080835404028352916020019161085f565b820191906000526020600020905b81548152906001019060200180831161084257829003601f168201915b505050505081565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff161415156108c357600080fd5b60018060038111156108d157fe5b600760009054906101000a900460ff1660038111156108ec57fe5b1415156108f857600080fd5b6002600760006101000a81548160ff0219169083600381111561091757fe5b02179055508160089080519060200190610932929190610cde565b50600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166108fc3073ffffffffffffffffffffffffffffffffffffffff16319081150290604051600060405180830381858888f1935050505015156109ac57600080fd5b5050565b60038054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610a465780601f10610a1b57610100808354040283529160200191610a46565b820191906000526020600020905b815481529060010190602001808311610a2957829003601f168201915b505050505081565b600760009054906101000a900460ff1681565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff16141515610abd57600080fd5b6000806003811115610acb57fe5b600760009054906101000a900460ff166003811115610ae657fe5b141515610af257600080fd5b6001600760006101000a81548160ff02191690836003811115610b1157fe5b02179055508260059080519060200190610b2c929190610cde565b508160069080519060200190610b43929190610cde565b50505050565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff16141515610bf157600080fd5b6001806003811115610bff57fe5b600760009054906101000a900460ff166003811115610c1a57fe5b141515610c2657600080fd5b6003600760006101000a81548160ff02191690836003811115610c4557fe5b02179055508160089080519060200190610c60929190610cde565b50600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166108fc3073ffffffffffffffffffffffffffffffffffffffff16319081150290604051600060405180830381858888f193505050501515610cda57600080fd5b5050565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10610d1f57805160ff1916838001178555610d4d565b82800160010185558215610d4d579182015b82811115610d4c578251825591602001919060010190610d31565b5b509050610d5a9190610d5e565b5090565b610d8091905b80821115610d7c576000816000905550600101610d64565b5090565b905600a165627a7a72305820e69dc9f1112107596780c8566cf6e308f37a8a86fc96c2835cd7929982aa5e780029";

    private ProofOfDelivery_sol_ProofOfDelivery(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    private ProofOfDelivery_sol_ProofOfDelivery(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public RemoteCall<String> deliveryServicePartnerId() {
        Function function = new Function("deliveryServicePartnerId", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> sendingServicePartnerId() {
        Function function = new Function("sendingServicePartnerId", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> deliveryServiceDeliveryId() {
        Function function = new Function("deliveryServiceDeliveryId", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> value() {
        Function function = new Function("value", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> proofOfDelivery() {
        Function function = new Function("proofOfDelivery", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> confirmReading(String _proofOfDelivery) {
        Function function = new Function(
                "confirmReading", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_proofOfDelivery)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> sendingServiceDeliveryId() {
        Function function = new Function("sendingServiceDeliveryId", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> state() {
        Function function = new Function("state", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint8>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<TransactionReceipt> confirmDeposition(String _deliveryServicePartnerId, String _deliveryServiceDeliveryId) {
        Function function = new Function(
                "confirmDeposition", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_deliveryServicePartnerId), 
                new org.web3j.abi.datatypes.Utf8String(_deliveryServiceDeliveryId)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> deliveryService() {
        Function function = new Function("deliveryService", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> sendingService() {
        Function function = new Function("sendingService", 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> confirmExpiration(String _proofOfDelivery) {
        Function function = new Function(
                "confirmExpiration", 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_proofOfDelivery)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public static RemoteCall<ProofOfDelivery_sol_ProofOfDelivery> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue, String _sendingServicePartnerId, String _sendingServiceDeliveryId, String _deliveryService) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_sendingServicePartnerId), 
                new org.web3j.abi.datatypes.Utf8String(_sendingServiceDeliveryId), 
                new org.web3j.abi.datatypes.Address(_deliveryService)));
        return deployRemoteCall(ProofOfDelivery_sol_ProofOfDelivery.class, web3j, credentials, gasPrice, gasLimit, BINARY, encodedConstructor, initialWeiValue);
    }

    public static RemoteCall<ProofOfDelivery_sol_ProofOfDelivery> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit, BigInteger initialWeiValue, String _sendingServicePartnerId, String _sendingServiceDeliveryId, String _deliveryService) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_sendingServicePartnerId), 
                new org.web3j.abi.datatypes.Utf8String(_sendingServiceDeliveryId), 
                new org.web3j.abi.datatypes.Address(_deliveryService)));
        return deployRemoteCall(ProofOfDelivery_sol_ProofOfDelivery.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, encodedConstructor, initialWeiValue);
    }

    public static ProofOfDelivery_sol_ProofOfDelivery load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new ProofOfDelivery_sol_ProofOfDelivery(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    public static ProofOfDelivery_sol_ProofOfDelivery load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new ProofOfDelivery_sol_ProofOfDelivery(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }
}
