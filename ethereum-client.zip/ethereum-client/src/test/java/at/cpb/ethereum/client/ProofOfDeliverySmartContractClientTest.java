package at.cpb.ethereum.client;

import org.junit.Test;

import java.math.BigInteger;

public class ProofOfDeliverySmartContractClientTest {

    private static final BigInteger WEI_VALUE = new BigInteger("10000000000000000000"); // 10 ETHER

    private static final String NODE_1_RPC_URL = "http://192.168.2.147:8545";
    private static final String FROM_ACCOUNT = "0x0066bD086b99f360Dce0BCf1Ecf52EB5de46dCB6";
    private static final String FROM_ACCOUNT_PASSWORD = "zether";

    private static final String NODE_2_RPC_URL = "http://192.168.2.148:8545";
    private static final String RECEIVER_ACCOUNT = "0x005002E8cAE8f613959214e271C3453613078858";
    private static final String RECEIVER_ACCOUNT_PASSWORD = "zether";

    @Test
    public void testDeployProofOfDelivery() {
        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);

        String contractAddress = client.deployContract("sendingServicePartnerId", "sendingServiceDeliveryId", RECEIVER_ACCOUNT, WEI_VALUE);
        System.out.println("contractAddress: " + contractAddress);
    }

    @Test
    public void testConfirmDeposition() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_2_RPC_URL, RECEIVER_ACCOUNT, RECEIVER_ACCOUNT_PASSWORD);
        client.confirmDeposition(contractAddress, "deliveryServicePartnerId", "deliveryServiceDeliveryId");
    }

    @Test
    public void testConfirmReading() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_2_RPC_URL, RECEIVER_ACCOUNT, RECEIVER_ACCOUNT_PASSWORD);
        client.confirmReading(contractAddress, "proofOfDeliveryXml");
    }

    @Test
    public void testConfirmExpiration() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_2_RPC_URL, RECEIVER_ACCOUNT, RECEIVER_ACCOUNT_PASSWORD);
        client.confirmExpiration(contractAddress, "proofOfDeliveryXml");
    }

    // Methods for reading the state of the contract

    @Test
    public void testGetState() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        BigInteger state = client.getState(contractAddress);
        System.out.println("state: " + state);
    }

    @Test
    public void testGetProofOfDelivery() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String proofOfDelivery = client.getProofOfDelivery(contractAddress);
        System.out.println("proofOfDelivery: " + proofOfDelivery);
    }

    @Test
    public void testGetSendingService() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String sendingService = client.getSendingService(contractAddress);
        System.out.println("sendingService: " + sendingService);
    }

    @Test
    public void testGetSendingServicePartnerId() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String sendingServicePartnerId = client.getSendingServicePartnerId(contractAddress);
        System.out.println("sendingServicePartnerId: " + sendingServicePartnerId);
    }

    @Test
    public void testGetSendingServiceDeliveryId() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String sendingServiceDeliveryId = client.getSendingServiceDeliveryId(contractAddress);
        System.out.println("sendingServiceDeliveryId: " + sendingServiceDeliveryId);
    }

    @Test
    public void testGetDeliveryService() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String deliveryService = client.getDeliveryService(contractAddress);
        System.out.println("deliveryService: " + deliveryService);
    }

    @Test
    public void testGetDeliveryServicePartnerId() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String deliveryServicePartnerId = client.getDeliveryServicePartnerId(contractAddress);
        System.out.println("deliveryServicePartnerId: " + deliveryServicePartnerId);
    }

    @Test
    public void testGetDeliveryServiceDeliveryId() {
        String contractAddress = "TODO";

        ProofOfDeliverySmartContractClient client = new ProofOfDeliverySmartContractClient(NODE_1_RPC_URL, FROM_ACCOUNT, FROM_ACCOUNT_PASSWORD);
        String deliveryServiceDeliveryId = client.getDeliveryServiceDeliveryId(contractAddress);
        System.out.println("deliveryServiceDeliveryId: " + deliveryServiceDeliveryId);
    }
}
